<li class="parent">
    <a href="javascript:void(0);" data-target="#pengajuan" data-toggle="submenu" data-parent=".topmenu">
        <span class="figure"><i class="ico-file6"></i></span>
        <span class="text">Pengajuan</span>
        <span class="arrow"></span>
    </a>

    <ul class="submenu collapse" id="pengajuan">
        <li class="submenu-header ellipsis">Pengajuan</li>
        <li class="">
            <a data-toggle="tooltip" title="Daftar Pengajuan" href="<?php echo base_url('ksb_ren/pengajuan/') ?>">
                <span class="text">Daftar Pengajuan</span>
            </a>
        </li>
    </ul>
</li>

<li class="chat">
    <a href="<?php echo base_url('/chat'); ?>">
        <span class="figure"><i class="ico-envelope"></i></span>
        <span class="text">Chat ke BLP</span>
    </a>
</li>

