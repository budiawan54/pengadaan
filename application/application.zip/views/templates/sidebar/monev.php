<li class="parent">
    <a href="javascript:void(0);" data-target="#pengajuan" data-toggle="submenu" data-parent=".topmenu">
        <span class="figure"><i class="ico-file6"></i></span>
        <span class="text">Pengajuan</span>
        <span class="arrow"></span>
    </a>

    <ul class="submenu collapse" id="pengajuan">
        <li class="submenu-header ellipsis">Pengajuan</li>
        <li class="">
            <a data-toggle="tooltip" title="Daftar Pengajuan" href="<?php echo base_url('monev/pengajuan/') ?>">
                <span class="text">Daftar Pengajuan</span>
            </a>
        </li>
    </ul>
</li>

