

<div class="page-header page-header-block">
    <div class="page-header-section">
        <h4 class="title semibold">Daftar Pengadaan</h4>
    </div>
    <div class="page-header-section">
        <div class="toolbar">
            <ol class="breadcrumb breadcrumb-transparent nm">
                <li><a href="javascript:void(0);">Pengajuan</a></li>
                <li class="active">Daftar</li>
            </ol>
        </div>
    </div>
</div>

<?php $this->load->view('universal/daftar_pengajuan_table'); ?>