<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Aplikasi Layanan Pengadaan &#8226; Kabupaten Buleleng</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo base_url('resources/image/logo.png') ?>">
    
    <link href="<?php echo base_url('resources/front') ?>/css/base.css" rel="stylesheet">
    
    <!-- Google web fonts -->
   <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Gochi+Hand' rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Lato:300,400' rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Lato:300,400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="/resources/plugins/flot/css/flot.css">
        

    <!--[if lt IE 9]>
      <script src="http://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="http://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    </head>
    <body>
        <header id="plain">
                <div id="top_line">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-6"><i class="icon-phone"></i><strong>0045 043204434</strong></div>
                            
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <ul id="top_links">
                                    <li>
                                        <div class="dropdown dropdown-access">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" id="access_link">Sign in</a>
                                            <div class="dropdown-menu">
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                                        <a href="#" class="bt_facebook">
                                                            <i class="icon-facebook"></i>Facebook </a>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                                        <a href="#" class="bt_paypal">
                                                            <i class="icon-paypal"></i>Paypal </a>
                                                    </div>
                                                </div>
                                                <div class="login-or">
                                                    <hr class="hr-or">
                                                    <span class="span-or">or</span>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control" id="inputUsernameEmail" placeholder="Email">
                                                </div>
                                                <div class="form-group">
                                                    <input type="password" class="form-control" id="inputPassword" placeholder="Password">
                                                </div>
                                                <a id="forgot_pw" href="#">Forgot password?</a>
                                                <input type="submit" name="Sign in" value="Sign in" id="Sign_in" class="button_drop">
                                                <input type="submit" name="Sign up" value="Sign up" id="Sign_up" class="button_drop outline">
                                            </div>
                                        </div><!-- End Dropdown access -->
                                    </li>
                                </ul>
                            </div>
                        </div><!-- End row -->
                    </div><!-- End container-->
                </div><!-- End top line-->
                
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <div id="logo">
                                <a href="index.html"><img src="img/logo.png" width="160" height="34" alt="City tours" data-retina="true" class="logo_normal"></a>
                                <a href="index.html"><img src="img/logo_sticky.png" width="160" height="34" alt="City tours" data-retina="true" class="logo_sticky"></a>
                            </div>
                        </div>

                        <nav class="col-md-9 col-sm-9 col-xs-9">
                            <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="javascript:void(0);"><span>Menu mobile</span></a>
                            <div class="main-menu">
                                <div id="header_menu">
                                    <img src="img/logo_sticky.png" width="160" height="34" alt="City tours" data-retina="true">
                                </div>
                                <a href="#" class="open_close" id="close_in"><i class="icon_set_1_icon-77"></i></a>
                                <ul>
                                    <li class="submenu">
                                        <a href="javascript:void(0);" class="show-submenu">Buleleng Kab <i class="icon-down-open-mini"></i></a><ul>
                                            <li><a href="index.html">Beranda</a></li>
                                            <li><a href="index.html">SIMPEG</a></li>
                                            <li><a href="index.html">LPSE</a></li>
                                            <li><a href="index.html">PILBKD</a></li>
                                            <li><a href="index.html">BANK DATA</a></li>
                                            <li><a href="index.html">SIPKD</a></li>
                                            <li><a href="index.html">INSTANSI</a></li>
                                        </ul>
                                    </li>

                                    <li class="submenu">
                                        <a href="">LPSE</a>
                                    </li>

                                </ul>
                            </div><!-- End main-menu -->
                        </nav>
                    </div>
                </div><!-- container -->
            </header>
        
               
            <section class="parallax-window" data-parallax="scroll" data-image-src="/resources/image/6.jpg" data-natural-width="1400" data-natural-height="470">
                <div class="parallax-content-1">
                    <div class="animated fadeInDown">
                    <h1>Selamat Datang</h1>
                    <p>di Aplikasi Layanan Pengadaan Kabupaten Buleleng</p>
                    </div>
                </div>
            </section><!-- End Section -->
        
        <div id="position">
                <div class="container">
                            <ul>
                            <li><a href="#">Home</a></li>
                            <li>Login</li>
                            </ul>
                </div>
            </div><!-- End Position -->


            <div class="container margin_60">
                <div class="main_title">
                    <h2><span>PENGADAAN</span> YANG TELAH DIAJUKAN</h2>
                    <p>
                        Berikut Grafik Pengadaan Yang Telah diajukan
                    </p>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <div class="feature_home">
                    
                            <div class="chart mt10" id="chart-audience" style="height:300px;"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-user"></i> Login Akun</h3>
                            </div>
                            <div class="panel-body">     
                                        <form  method="POST" name="form-login" action="<?php echo base_url('/login') ?>">
                                            <div style="text-align: center">
                                                <img src="/resources/image/logo.png" style="width: 30%; margin-bottom: 10px" class="pb10">

                                            </div>
                                            <div class="alert alert-success fade in">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                <p class="mb10">Silahkan memasukan data akun anda untuk melanjutkan ke halaman utama.</p>
                                            </div>

                                            <div class="form-group">
                                                    <input name="Username" value="" type="text" id="username" class="form-control input-sm" placeholder="Username">
                                            </div>
                                            <div class="form-group">
                                                    <input name="Password" value="" type="password" class="form-control input-sm" placeholder="Password">
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn_1"><span class="semibold">Login</span></button>
                                                <!-- <a href="#" class="btn_2">Lupa Password</a> -->
                                            </div>
                                        </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


                     
            <footer>
                    <div class="container">
                        
                            <div class="col-md-12">
                                <div id="social_footer">
                                    <ul>
                                        <li><a href="#"><i class="icon-facebook"></i></a></li>
                                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                                        <li><a href="#"><i class="icon-google"></i></a></li>
                                        <li><a href="#"><i class="icon-instagram"></i></a></li>
                                        <li><a href="#"><i class="icon-pinterest"></i></a></li>
                                        <li><a href="#"><i class="icon-vimeo"></i></a></li>
                                        <li><a href="#"><i class="icon-youtube-play"></i></a></li>
                                        <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                    </ul>
                                    <p>© Citytours 2015</p>
                                </div>
                            </div>
                        </div><!-- End row -->
                    </div><!-- End container -->
                </footer><!-- End footer -->




    
        <div id="toTop"></div><!-- Back to top button -->

         <!-- Common scripts -->
        <script src="<?php echo base_url('resources/front') ?>/js/jquery-1.11.2.min.js"></script>
        <script src="<?php echo base_url('resources/front') ?>/js/common_scripts_min.js"></script>
        <script src="<?php echo base_url('resources/front') ?>/js/functions.js"></script>

         <!-- Specific scripts -->   
        <script src="<?php echo base_url('resources/front') ?>/js/jquery.simpleWeather.min.js"></script> 
    


    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.js"></script>
    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.resize.js"></script>
    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.categories.js"></script>
    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.time.js"></script>
    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.tooltip.js"></script>
    <script type="text/javascript" src="/resources/plugins/flot/js/jquery.flot.spline.js"></script>
    <script type="text/javascript">
        $(function(){
             $.plot('#chart-audience', [{
                label: 'Jumlah Pengajuan',
                color: '#DC554F',
                data: [
                    <?php
                        foreach ($ar as $key => $value) {
                            echo "['".$key."', ".$value."],";
                        }
                    ?>
                ]
            }], {
                series: {
                    lines: {
                        show: false
                    },
                    splines: {
                        show: true,
                        tension: 0.4,
                        lineWidth: 2,
                        fill: 0.8
                    },
                    points: {
                        show: true,
                        radius: 4
                    }
                },
                grid: {
                    borderColor: 'rgba(0, 0, 0, 0.05)',
                    borderWidth: 1,
                    hoverable: true,
                    backgroundColor: 'transparent'
                },
                tooltip: true,
                tooltipOpts: {
                    content: '%x : %y',
                    defaultTheme: false
                },
                xaxis: {
                    tickColor: 'rgba(0, 0, 0, 0.05)',
                    mode: 'categories'
                },
                yaxis: {
                    tickColor: 'rgba(0, 0, 0, 0.05)'
                },
                shadowSize: 0
            });
        });
    </script>
    </body>
</html>