


<div class="panel panel-default">
	<div class="panel-heading">
		<h3 class="panel-title">Aksi Pengajuan</h3>
	</div>

	<div class="panel-body">
		<div class="alert alert-info">
			<h4 class="semibold title">Petunjuk</h4>
			<input type="hidden" name="Id_Pengajuan_Pengadaan" value="<?php echo $pengajuan['Id_Pengajuan_Pengadaan'] ?>">
			<p>Silahkan isi catatan pada setiap kelengkapan dan tekan tombol submit untuk menyimpan</p>
		</div>
		<input type="submit" class="btn btn-success btn-block" value="Simpan Catatan Kelengkapan">
	</div>
</div>

</form>