<?php
	
    if($this->session->flashdata('pesan') != null) {
        
		$pesan      = $this->session->flashdata('pesan');
		$isi_pesan  = $pesan['isi'];
		$tipe_pesan = $pesan['tipe'];

        if ($tipe_pesan == 'error'){
        	$color_pesan = '#C0392B';
        }
        else{
        	$color_pesan = '#27ae60';
        }
?>
		<script type="text/javascript">
		    $(function(){
		        $.amaran({
		            'content'   :{
						bgcolor:'<?php echo $color_pesan; ?>',
						color:'#fff',
						title: 'Pemberitahuan', 
						message:'<?php echo $isi_pesan; ?>'
		            },
					'position'          :'top right',
					'theme'             :'colorful',
					'sticky'            : true,
					'closeButton'       : true,
					'closeOnClick'      : false,
		        });
		    });
		</script>
<?php

    }
	
?>