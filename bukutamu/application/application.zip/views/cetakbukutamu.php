<style type="text/css">
	.table{
		width: 100%;
		border-collapse: collapse;
	}
	.table tr th, .table tr td{
		border : 1px solid #7B7B7B;
		padding: 3px;
	}
	body{
		font-size: 0.8em;
	}
</style>

<body>

<h3 style="text-align: center">
	Daftar Isi Buku Tamu
</h3>
<h5 style="text-align: center">Tanggal <?php echo $tgl ?></h5>


<table class="table">
	
	<tr>
			<th>No</th>
			<th>Nama</th>
			<th>Instansi</th>
			<th>Unit Tujuan</th>
			<th>Catatan</th>
	</tr>
	<?php  
		foreach ($buku_tamu as $key => $value) {
			$i = $key  + 1;
			?>
				<tr>
					<td><?php echo $i ?></td>
					<td><?php echo $value['nama'] ?></td>
					<td><?php echo $value['instansi'] ?></td>
					<td><?php echo $value['Nama_Jabatan'] ?></td>
					<td><?php echo $value['catatan'] ?></td>
				</tr>
			<?php
		}
	?>
</table>
</body>