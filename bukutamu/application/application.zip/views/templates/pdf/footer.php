<div style="text-align: center; font-size: 0.7em;">
	
	Gedung Unit VI Lantai I Jalan Pahlawan Nomor 1 Singaraja-Bali 81117<br>
	Telepon (0362) 22349; 21446; 26269; 21985; 21744; 21244; Fax (0362) 22380<br>
	http://seta.bulelengkab.go.id<br>
	e-mail : ulp@bulelengkab.go.id

</div>