<div class="row bg-light" style="min-height: 500px;">
    <div class="col-md-12 text-center">
        <h2 class="font-size-normal">
            Daftar Buku Tamu
            <small class="heading heading-solid center-block"></small>
        </h2>
    </div>
    <div class="col-md-8 col-md-offset-2 text-center">
    <?php
        if ($user['Slug_Jabatan'] != 'admin'){
    ?>

        <p class="lead">
            Hari ini <?php echo date('Y-m-d') ?> ada <?php echo $jmlAntrian ?> antrian yang menunggu anda
        </p>

    <?php
        }
    ?>
    </div>

    <div class="col-md-12 " >
        
        <div class="well">
            <form class="form-inline" id="formTgl">
                <div class="form-group">
                    <input type="text" id="tgl_input" class="form-control input-sm datepicker" placeholder="Tanggal" value="<?php echo date('Y-m-d') ?>">
                    <button type="submit" class="button button-rounded button-sm button-pasific" style="margin-top: 5px;"><i class="fa fa-filter"></i> Saring</button>
                    <a onclick="cetakBukuTamu()" class="button button-rounded button-sm button-success" href="javascript:void(0)" style="margin-top: 5px;"><i class="fa fa-print"></i> Cetak</a>
                 </div>
            </form>
        </div>
        <div class="table-responsive">
        <table class="table " id="tableBuku">
            <thead>
                <tr>
                    <th>No Antrian</th>
                    <th>Nama</th>
                    <th>Instansi</th>
                    <th>Waktu Datang</th>
                    <?php
                        if ($user['Slug_Jabatan'] == 'admin'){
                    ?>
                        <th>Unit Tujuan</th>
                    <?php
                        }
                    ?>
                    <th>Status</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        </div>
    </div>
</div>


<div class="modal fade " id="modalUbahStatusM" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog">
    <form action="<?php echo base_url('home/simpanEditStatusPengunjung') ?>" method="POST">

       <div class="modal-content " style="top: 20px;">
            <div class="modal-header">
                Edit Status Pengunjung
            </div>
           <div class="modal-body">
                <div id="modalUbahStatusFormTarget"></div>
           </div>
           <div class="modal-footer">
                <button type="submit" class="button button-rounded button-pasific"><i class="fa fa-save"></i> Simpan</button>
           </div>
       </div>
    </form>
   </div>
</div>


<div class="modal fade " id="modalUbahDetailM" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog modal-lg">
    <form action="<?php echo base_url('home/simpanEditDetailPengunjung') ?>" method="POST">

       <div class="modal-content " style="top: 20px;">
            <div class="modal-header">
                Detail Pengunjung
            </div>
           <div class="modal-body">
                <div id="modalUbahDetailFormTarget"></div>
           </div>
           <div class="modal-footer">
                <button type="submit" class="button button-rounded button-pasific"><i class="fa fa-save"></i> Simpan</button>
           </div>
       </div>
    </form>
   </div>
</div>

<script type="text/javascript">
    function modalUbahStatus(id_buku_tamu){
        $.get("<?php echo base_url('ajax/modalUbahStatus') ?>/" + id_buku_tamu, function(e){
            $('#modalUbahStatusFormTarget').html(e);
            $('#modalUbahStatusM').modal('show');
        })
    }

    function modalDetailPengunjung(id_buku_tamu){
        $.get("<?php echo base_url('ajax/modalDetailPengunjung') ?>/" + id_buku_tamu, function(e){
            $('#modalUbahDetailFormTarget').html(e);
            $('#modalUbahDetailM').modal('show');
        })
    }  

    

    var master_url = "<?php echo base_url('ajax/getIsiBukuTamu') ?>";

    var result_url = master_url + '/' + "<?php echo date('Y-m-d') ?>";
    var config_status_buku_tamu = <?php echo json_encode(renderStatusBukuTamu()) ?>;

    function cetakBukuTamu(){
        var tgl = $('#tgl_input').val();

        location.href = '<?php echo base_url('home/cetakBukuTamu/') ?>' + '/' + tgl;
    }

    $(function(){
        var TableData = $('#tableBuku').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [[ 0, "desc" ]],
            "ajax": {
                "url" : result_url,
                "type" : "POST"
            },
            fnDrawCallback: function (oSettings) {
                $('[data-toggle="tooltip"]').tooltip(); 
            },
            columns : [
                {data : "no_urut"},
                {data : "nama"},
                {data : "instansi"},
                {data : "created_at"},
                <?php
                    if ($user['Slug_Jabatan'] == 'admin'){
                        echo '{data : "unit_tujuan"},';
                    }
                ?>
                {
                    data : "status",
                    render : function(data){
                        return '<label title="'+ data +'" data-toggle="tooltip" class="label label-'+ config_status_buku_tamu[data] +'">'+ data +'</label>';
                    }
                },
                {data : "id_buku_tamu", 
                    render: function(data){

                        return '<a href="javascript:void(0)" onclick="modalUbahStatus('+ data +')" title="Ubah status" data-toggle="tooltip" class="button button-xs button-rounded button-orange">Edit Status</a>&nbsp;&nbsp; <a href="javascript:void(0)" onclick="modalDetailPengunjung('+ data +')" class="button button-xs button-rounded button-pasific"><i class="fa fa-check"></i> Detail</a>';
                    }
                }

            ]
        });


        $('#formTgl').on('submit', function(e){

            var tgl = $('#tgl_input').val();
            var url_target = master_url +'/'+ tgl;
            TableData.ajax.url(url_target).load();
            e.preventDefault();

        })




    })
</script>