<div class="row">
	<div class="col-md-6">
        <table class="table">
			<tr>
				<td>Nama</td>
				<td><?php echo $buku['nama'] ?></td>
			</tr>
			<tr>
				<td>NIP/No. KTP</td>
				<td><?php echo $buku['nip_noktp'] ?></td>
			</tr>
			<tr>
				<td>Instansi</td>
				<td><?php echo $buku['instansi'] ?></td>
			</tr>
			<tr>
				<td>No. Telp</td>
				<td><?php echo $buku['no_telp'] ?></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><?php echo $buku['email'] ?></td>
			</tr>
			<tr>
				<td>Unit Tujuan</td>
				<td><?php echo $buku['unit_tujuan'] ?></td>
			</tr>
			<tr>
				<td>Keperluan</td>
				<td><?php echo $buku['keperluan'] ?></td>
			</tr>

        </table>
	</div>
	<div class="col-md-6">
		
		<div style="text-align: center; width: 100%">
			<img src="<?php echo $buku['foto'] ?>"style="margin-bottom: 10px; width: 60%; text-align: center;">
		</div>
		<div class="form-group">
			<label class="control-label">Catatan Pengunjung</label>
			<textarea class="form-control" name="catatan"><?php echo $buku['catatan'] ?></textarea>
		</div>

	</div>

	<input type="hidden" name="id_buku_tamu" value="<?php echo $buku['id_buku_tamu'] ?>">
</div>
