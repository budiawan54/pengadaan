<div class="row bg-light" style="min-height: 500px;">
    <div class="col-md-12 text-center">
        <h2 class="font-size-normal">
            Respon Pengunjung
            <small class="heading heading-solid center-block"></small>
        </h2>
    </div>
    <div class="col-md-8 col-md-offset-2 text-center">
    
    </div>

    <div class="col-md-12 " >
        
        <!-- <div class="well">
            <form class="form-inline" id="formTgl">
                <div class="form-group">
                    <input type="text" id="tgl_input" class="form-control input-sm datepicker" placeholder="Tanggal" value="<?php echo date('Y-m-d') ?>">
                    <button type="submit" class="button button-rounded button-sm button-pasific" style="margin-top: 5px;"><i class="fa fa-filter"></i> Saring</button>
                 </div>
            </form>
        </div> -->
        <div class="table-responsive">
        <table class="table " id="tableBuku">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Jumlah Puas</th>
                    <th>Jumlah Tidak Puas</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        </div>
    </div>
</div>

<script type="text/javascript">

$(function(){
	var master_url = "<?php echo base_url('ajax/getResponPengunjung') ?>";

	var result_url = master_url + '/' + "<?php echo date('Y-m-d') ?>";

    var TableData = $('#tableBuku').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [[ 0, "desc" ]],
        "ajax": {
            "url" : result_url,
            "type" : "POST"
        },
        fnDrawCallback: function (oSettings) {
            $('[data-toggle="tooltip"]').tooltip(); 
        },
        columns : [
            {data : "tgl"},
            {data : "nilai_up"},
            {data : "nilai_down"}
        ]
    });

    $('#formTgl').on('submit', function(e){

        var tgl = $('#tgl_input').val();
        var url_target = master_url +'/'+ tgl;
        TableData.ajax.url(url_target).load();
        e.preventDefault();

    })
});

</script>